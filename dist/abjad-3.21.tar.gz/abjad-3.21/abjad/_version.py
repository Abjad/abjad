__version_info__ = (3, 21)
__version__ = ".".join(str(_) for _ in __version_info__[:2])
__version__ += "".join(__version_info__[2:])
